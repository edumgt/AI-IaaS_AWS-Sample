const AWS = require('aws-sdk');
const { getConfig } = require('./config');

let initialized = false;

function initializeAws() {
  if (initialized) return;

  const { region } = getConfig();
  // Lambda에서는 Execution Role 기반 자격증명(임시 STS)을 자동으로 사용합니다.
  // accessKeyId/secretAccessKey/sessionToken을 수동 주입하지 마세요.
  AWS.config.update({ region });

  initialized = true;
}

function getS3() {
  initializeAws();
  return new AWS.S3();
}

function getRekognition() {
  initializeAws();
  return new AWS.Rekognition();
}

module.exports = {
  getS3,
  getRekognition,
};
